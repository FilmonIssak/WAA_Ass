package miu.edu.lab2.Controller;

import miu.edu.lab2.Domain.User;
import miu.edu.lab2.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    UserService userService;


    @GetMapping
    public List<User> getAllUsers(){
        return (List<User>) userService.getAllUsers();
    }

    @GetMapping("/{id}")
    public User getUserById(@PathVariable int id){
        return userService.getUserById(id);
    }

    @GetMapping("/delete/{id}")
    public @ResponseBody void deleteUser(@PathVariable int id){
        userService.deleteUser(id);
    }

    @PostMapping("/update")
    public @ResponseBody void updateUser(int id,User user){
        userService.updateUser(id, user);
    }

    @PostMapping("/add")
    public @ResponseBody void addNewUser(User user) {
        userService.saveUser(user);
    }


}
