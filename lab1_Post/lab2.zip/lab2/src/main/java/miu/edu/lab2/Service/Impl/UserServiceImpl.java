package miu.edu.lab2.Service.Impl;

import miu.edu.lab2.Domain.User;
import miu.edu.lab2.Repo.UserRepo;
import miu.edu.lab2.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {


    @Autowired
    UserRepo userRepo;

    @Override
    public Iterable<User> getAllUsers() {
        return userRepo.findAll();
    }

    @Override
    public User getUserById(long id) {
        return  userRepo.findById(id).orElse(null);//userRepo.getById
    }

    @Override
    public void saveUser(User user) {
        userRepo.save(user);
    }

    @Override
    public void updateUser(int id, User user) {
        var existingUser = userRepo.findById(user.getId()).orElse(null);
        existingUser.setId(user.getId());
        existingUser.setName(user.getName());
        existingUser.setPosts(user.getPosts());
    }


    @Override
    public void deleteUser(long id) {
        userRepo.deleteById(id);
    }
}
