package miu.edu.lab2.Service;

import miu.edu.lab2.Domain.Post;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface PostService  {

    Iterable<Post> getAll();
    Post getById(long id);
    void save(Post post);

    void delete(long id);

    void update(Post post);
}
