package miu.edu.lab2.Service.Impl;

import miu.edu.lab2.Domain.Post;
import miu.edu.lab2.Repo.PostRepo;
import miu.edu.lab2.Service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostServiceImpl implements PostService {

    @Autowired
    PostRepo postRepo;


    @Override
    public List<Post> getAll() {
        return (List<Post>) postRepo.findAll();
    }

    @Override
    public Post getById(long id) {
        return postRepo.findById(id).orElse(null);
    }

    @Override
    public void save(Post post) {
        postRepo.save(post);
    }

    @Override
    public void delete(long id) {
        postRepo.deleteById(id);
    }

    @Override
    public void update(Post post) {
        var existingPost = postRepo.findById(post.getId()).orElse(null);
        existingPost.setId(post.getId());
        existingPost.setTitle(post.getTitle());
        existingPost.setTitle(post.getTitle());
        existingPost.setContent(post.getContent());
    }
}
