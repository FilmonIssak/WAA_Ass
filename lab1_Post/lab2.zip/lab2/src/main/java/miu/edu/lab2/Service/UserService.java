package miu.edu.lab2.Service;

import miu.edu.lab2.Domain.Post;
import miu.edu.lab2.Domain.User;

import java.util.List;

public interface UserService {

    Iterable<User> getAllUsers();
    public User getUserById(long id);
    public void saveUser(User user);
    public void updateUser(int id, User user);
    public void deleteUser(long id);
}
